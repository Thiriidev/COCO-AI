import crypto from "crypto";
import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
import { BedrockAgentClient, StartIngestionJobCommand } from "@aws-sdk/client-bedrock-agent";

const s3 = new S3Client({ region: "ap-southeast-2" });
const bedrockAgent = new BedrockAgentClient({ region: "ap-southeast-2" });

export const handler = async (event) => {
  try {
    console.log("S3 Event:", JSON.stringify(event, null, 2));

    const record = event.Records[0];
    const bucket = record.s3.bucket.name;
    const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));

    // Generate sessionId
    const sessionId = crypto.randomUUID();
    console.log("Generated session ID:", sessionId);

    // ✅ (Optional) Update object metadata with sessionId
    // For v3 you’d re-upload with metadata, or just rely on event for Bedrock

    // ✅ Trigger Bedrock Knowledge Base ingestion
    const cmd = new StartIngestionJobCommand({
      knowledgeBaseId: "YOUR_KB_ID",
      dataSourceId: "YOUR_DATASOURCE_ID",
    });
    const response = await bedrockAgent.send(cmd);

    console.log("Ingestion started:", response);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Ingestion triggered",
        sessionId,
        ingestionJob: response,
      }),
    };
  } catch (err) {
    console.error("Error in Lambda:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message }),
    };
  }
};
